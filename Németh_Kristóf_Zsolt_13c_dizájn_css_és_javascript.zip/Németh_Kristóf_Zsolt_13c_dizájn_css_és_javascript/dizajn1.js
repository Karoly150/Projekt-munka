// Dizájn 1: Kosár 
let cart = [];

function addToCart(item) {
  cart.push(item);
  alert(item + " hozzáadva a kosárhoz!");
  updateCart();
}

function updateCart() {
  const cartCount = document.getElementById('cart-count');
  cartCount.textContent = cart.length;
}

document.addEventListener("DOMContentLoaded", () => {
  const addButtons = document.querySelectorAll('.add-to-cart');
  addButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      addToCart(e.target.getAttribute('data-item'));
    });
  });
});
