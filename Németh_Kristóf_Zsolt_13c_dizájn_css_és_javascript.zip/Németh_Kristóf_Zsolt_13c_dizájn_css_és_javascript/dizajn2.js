// Dizájn 2: Kosár és rendelés
let order = [];

function addToOrder(item) {
  order.push(item);
  alert(item + " hozzáadva a rendeléshez!");
}

function completeOrder() {
  if (order.length === 0) {
    alert("A rendelés üres!");
  } else {
    alert("Rendelés befejezve: " + order.join(', '));
    order = [];
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const addButtons = document.querySelectorAll('.add-to-order');
  addButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      addToOrder(e.target.getAttribute('data-item'));
    });
  });
});
