// Dizájn 3: Rendelési funkció
let menu = [];

function addToMenu(item, price) {
  menu.push({ item, price });
  alert(item + " hozzáadva a menübe!");
}

function showOrder() {
  let orderSummary = menu.map(i => `${i.item}: ${i.price} Ft`).join("\n");
  alert("A rendelésed:\n" + orderSummary);
}

document.addEventListener("DOMContentLoaded", () => {
  const addButtons = document.querySelectorAll('.add-to-menu');
  addButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      const item = e.target.getAttribute('data-item');
      const price = e.target.getAttribute('data-price');
      addToMenu(item, price);
    });
  });
});
