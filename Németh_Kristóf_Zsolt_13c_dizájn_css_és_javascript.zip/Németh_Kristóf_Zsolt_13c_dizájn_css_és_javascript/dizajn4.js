// Dizájn 4: Foglalás rendszer
function submitReservation() {
    const name = document.getElementById('name').value;
    const date = document.getElementById('date').value;
    const guests = document.getElementById('guests').value;
    alert(`Foglalás sikeres!\nNév: ${name}\nDátum: ${date}\nVendégek száma: ${guests}`);
  }
  
  document.getElementById('reservation-form').addEventListener('submit', (e) => {
    e.preventDefault();
    submitReservation();
  });
  