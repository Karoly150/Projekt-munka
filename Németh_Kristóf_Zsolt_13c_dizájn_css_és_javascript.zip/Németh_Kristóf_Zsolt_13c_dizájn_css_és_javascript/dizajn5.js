// Dizájn 5: Kosár frissítése
let cartItems = [];

function addToCart(item, price) {
  cartItems.push({ item, price });
  alert(`${item} hozzáadva a kosárhoz!`);
}

function viewCart() {
  let cartSummary = cartItems.map(i => `${i.item}: ${i.price} Ft`).join("\n");
  alert("A kosarad:\n" + cartSummary);
}

document.addEventListener("DOMContentLoaded", () => {
  const addButtons = document.querySelectorAll('.add-to-cart');
  addButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      const item = e.target.getAttribute('data-item');
      const price = e.target.getAttribute('data-price');
      addToCart(item, price);
    });
  });
});
