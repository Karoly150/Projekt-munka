// Dizájn 6: Akciók kezelése
let specialOffers = [];

function addOffer(item) {
  specialOffers.push(item);
  alert(`${item} hozzáadva az akciókhoz!`);
}

function showOffers() {
  alert("Akciós menük: " + specialOffers.join(", "));
}

document.addEventListener("DOMContentLoaded", () => {
  const offerButtons = document.querySelectorAll('.add-to-offers');
  offerButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      addOffer(e.target.getAttribute('data-item'));
    });
  });
});
