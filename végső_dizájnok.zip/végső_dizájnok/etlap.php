<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="design/style.css">
  <title>Étlap – Mátyás Csárda</title>
</head>
<body>
  <header>
    <h1>Mátyás Csárda – Étlap</h1>
    <button id="themeToggle" class="theme-toggle" title="Világos/sötét mód">🌙</button>
  </header>
  <main>
    <?php
      // Itt jön az étlap eredeti tartalma ugye
      include("fejlec.php");
      echo "<h2>Ételeink</h2>";
      
    ?>
  </main>
  <script src="design/theme.js"></script>
</body>
</html>
